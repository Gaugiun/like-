<template>
    <message type="comment"></message>
</template>
<script>
import message from '@components/common/message'
export default {
    components: {
        message
    }
}
</script>
