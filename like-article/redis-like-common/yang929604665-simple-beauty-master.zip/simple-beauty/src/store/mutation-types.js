export const RECORD_TOKEN = 'RECORD_TOKEN'
export const SAVE_HEAD_IMG = 'SAVE_HEAD_IMG'
export const SAVE_UID = 'SAVE_UID'
export const SAVE_ACCOUNT = 'SAVE_ACCOUNT'
